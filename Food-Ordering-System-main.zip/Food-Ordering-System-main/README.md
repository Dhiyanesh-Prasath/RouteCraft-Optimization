# Food-Ordering-System
## Data Structures Used
Linked List – to implement menu items

Stack – to implement order items

Queue – to implement orders

